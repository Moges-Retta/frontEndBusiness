insert into products(title,description,rationale,marketPotential,rawMaterial,technology,benefits,catagories_id,cities_id)
values('test','test','test','test','test','test','test',(select id from catagories where name='test'),
(select id from cities where name='test'));