package com.investInEthio.ideas.domain;

public class ProductTest {
}
