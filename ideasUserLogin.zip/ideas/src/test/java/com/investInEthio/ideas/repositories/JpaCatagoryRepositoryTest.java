package com.investInEthio.ideas.repositories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
//@Import(JpaCatagoryRepository.class)
@Sql("/insertCatagory.sql")
public class JpaCatagoryRepositoryTest extends AbstractTransactionalJUnit4SpringContextTests {
    private final CatagoryRepository repository;

    public JpaCatagoryRepositoryTest(CatagoryRepository repository) {
        this.repository = repository;
    }
    @Test
    void findCatagoryByNaam(){
        repository.findByName("test").forEach(catagory ->
                assertThat(catagory.getName()).isEqualTo("test"));
    }
}
