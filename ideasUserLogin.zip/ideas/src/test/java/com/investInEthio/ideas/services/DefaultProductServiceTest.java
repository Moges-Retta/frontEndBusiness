package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.Catagory;
import com.investInEthio.ideas.domain.City;
import com.investInEthio.ideas.domain.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.investInEthio.ideas.repositories.ProductRepository;

import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class DefaultProductServiceTest {
    private DefaultProductService service;
    private Product product;
    @Mock
    private ProductRepository repository;

    @BeforeEach
    void beforeEach(){
        product = new Product("test","test","test","test",
                "test","test","test",new Catagory("test"),
                new City("test",1));
        service = new DefaultProductService(repository);
    }
    @Test
    void findByTitleContaining(){
        when(repository.findById(1)).thenReturn(Optional.of(product));
        assertThat(service.findById(1).get().getTitle().toLowerCase().contains("t"));
    }
    @Test
    void findByCatagoryName(){
        when(repository.findById(1)).thenReturn(Optional.of(product));
        assertThat(service.findById(1).get().getCatagory().getName().contains("t"));
    }
    @Test
    void findByTitleNotContaining(){
        assertThat(service.findByTitleContaining("z")).hasSize(0);
    }
    @Test
    void findByCatagoryNameNotContaining(){
        assertThat(service.findByCatagoryName("z")).hasSize(0);
    }
}
