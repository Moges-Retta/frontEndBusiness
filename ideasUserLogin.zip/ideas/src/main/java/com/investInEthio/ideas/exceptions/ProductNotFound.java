package com.investInEthio.ideas.exceptions;

public class ProductNotFound extends RuntimeException{
    private static final long serialVersionUID = 1L;
}
