package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.User;
import com.investInEthio.ideas.services.ProductService;
import org.springframework.data.repository.query.Param;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class IndexController {
    private ProductService service;

    public IndexController(ProductService service) {
        this.service = service;
    }

    @GetMapping
    public ModelAndView index() {
        return new ModelAndView("index");
    }


}
