package com.investInEthio.ideas.domain;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotBlank
    private  String firstname;
    @NotBlank
    private  String lastname;
    @NotNull
    @Email
    private  String emailAdres;
    @NotBlank
    private  String password;
    @DateTimeFormat(style = "S-")
    private  LocalDate membersince;
    private int actief;
    public User(@NotBlank String firstname, @NotBlank String lastname, @NotNull @Email String emailAdres, @NotBlank String password) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.emailAdres = emailAdres;
        this.password = password;
        this.membersince=LocalDate.now();
        this.actief = 1;
    }

    protected User(){}

    public long getId() {
        return id;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getEmailAdres() {
        return emailAdres;
    }

    public String getPassword() {
        return password;
    }

    public LocalDate getMembersince() {
        return membersince;
    }
}
