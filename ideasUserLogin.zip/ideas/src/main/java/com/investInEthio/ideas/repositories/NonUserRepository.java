package com.investInEthio.ideas.repositories;

import com.investInEthio.ideas.domain.NonUser;
import com.investInEthio.ideas.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NonUserRepository  extends JpaRepository<NonUser,Long> {
}
