package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.Product;
import com.investInEthio.ideas.exceptions.ProductNotFound;
import com.investInEthio.ideas.services.ProductService;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/products")
@CrossOrigin(exposedHeaders = "Location")
@ExposesResourceFor(Product.class)
public class ProductDetailController {
    private final ProductService service;

    public ProductDetailController(ProductService service) {
        this.service = service;
    }

    @GetMapping("{id}")
    ProductDetail get(@PathVariable long id) {
        var product = service.findById(id).orElseThrow(ProductNotFound::new);
        return new ProductDetail(product);

    }
    private static class ProductDetail {
        private final long id;
        private  final String title;
        private  final String description;
        private  final String rationale;
        private  final String marketPotential;
        private  final String rawMaterial;
        private  final String technology;
        private  final String benefits;


        public ProductDetail(Product product) {
            id=product.getId();
            title = product.getTitle();
            description = product.getDescription();
            rationale = product.getRationale();
            marketPotential = product.getMarketPotential();
            rawMaterial = product.getRawMaterial();
            technology = product.getTechnology();
            benefits = product.getBenefits();

        }

        public long getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getRationale() {
            return rationale;
        }

        public String getMarketPotential() {
            return marketPotential;
        }

        public String getRawMaterial() {
            return rawMaterial;
        }

        public String getTechnology() {
            return technology;
        }

        public String getBenefits() {
            return benefits;
        }
    }

}
