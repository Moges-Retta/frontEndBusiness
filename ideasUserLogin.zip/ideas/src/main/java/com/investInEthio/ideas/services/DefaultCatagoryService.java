package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.Catagory;
import com.investInEthio.ideas.repositories.CatagoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class DefaultCatagoryService implements CatagoryService{
    private CatagoryRepository repository;

    public DefaultCatagoryService(CatagoryRepository repository) {
        this.repository = repository;
    }

    @Override
    public Optional<Catagory> findById(long id) {
        return repository.findById(id);
    }


    @Override
    public List<Catagory> findALL() {
        return repository.findAll();
    }
}
