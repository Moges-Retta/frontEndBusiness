package com.investInEthio.ideas.controllers;
import com.investInEthio.ideas.domain.Product;
import com.investInEthio.ideas.services.ProductService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.EntityLinks;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.web.bind.annotation.*;

import java.util.stream.Collectors;

@RestController
//@RequestMapping("/search")
@CrossOrigin(exposedHeaders = "Location")
@ExposesResourceFor(Product.class)
//@Controller
@RequestMapping(value="/search",method = RequestMethod.GET)
public class SearchController {
    private final ProductService service;
    private final EntityLinks entityLinks;

    public SearchController(ProductService service, EntityLinks entityLinks) {
        this.service = service;
        this.entityLinks = entityLinks;
    }
    @GetMapping
    CollectionModel<EntityModel<ProductIdName>> get(@RequestParam String keyword) {
        return CollectionModel.of(service.findByTitleContaining(keyword).stream()
                .map(product -> EntityModel.of(new ProductIdName(product),
                        entityLinks.linkToItemResource(Product.class, product.getId())))
                .collect(Collectors.toList()), entityLinks.linkToCollectionResource(Product.class));
    }
    private static class ProductIdName {
        private final long id;
        private final String name;

        public ProductIdName(Product product) {
            id = product.getId();
            name = product.getTitle();
        }

        public long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    /*@GetMapping
    public ModelAndView search(@RequestParam String keyword) {
        return new ModelAndView("product","products",
                service.findByTitleContaining(keyword));
    }*
    @GetMapping("/capital")
    public ModelAndView searchBudget(@RequestParam String keyword) {
        return new ModelAndView("product","products",
                service.findByTitleContaining(keyword));
    }*/
    }
}
