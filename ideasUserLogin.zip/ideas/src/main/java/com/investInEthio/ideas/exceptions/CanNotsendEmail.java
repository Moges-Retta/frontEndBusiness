package com.investInEthio.ideas.exceptions;

public class CanNotsendEmail extends RuntimeException{
    private static final long serialVersionUID = 1L;
    public CanNotsendEmail(Exception error) { super(error); }

}
