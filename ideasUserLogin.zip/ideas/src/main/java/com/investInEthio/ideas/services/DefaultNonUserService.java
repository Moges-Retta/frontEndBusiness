package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.NonUser;
import com.investInEthio.ideas.domain.User;
import com.investInEthio.ideas.repositories.NonUserRepository;
import org.springframework.stereotype.Service;

@Service
public class DefaultNonUserService implements NonUserService{
    private final NonUserRepository repository;

    public DefaultNonUserService(NonUserRepository repository) {
        this.repository = repository;
    }

    @Override
    public void create(NonUser user) {
        repository.save(user);
    }
}
