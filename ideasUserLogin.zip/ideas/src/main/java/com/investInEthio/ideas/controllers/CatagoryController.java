package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.Catagory;
import com.investInEthio.ideas.domain.Product;
import com.investInEthio.ideas.services.CatagoryService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.EntityLinks;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.web.bind.annotation.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/catagories")
@CrossOrigin(exposedHeaders = "Location")
@ExposesResourceFor(Catagory.class)
public class CatagoryController {
    private CatagoryService service;
    private final EntityLinks entityLinks;

    public CatagoryController(CatagoryService service, EntityLinks entityLinks) {
        this.service = service;
        this.entityLinks = entityLinks;
    }
    @GetMapping
        CollectionModel<EntityModel<CatagoryIdName>> findAll() {
            return CollectionModel.of(service.findALL().stream()
                    .map(catagory -> EntityModel.of(new CatagoryIdName(catagory),
                            entityLinks.linkToItemResource(Catagory.class, catagory.getId())))
                    .collect(Collectors.toList()), entityLinks.linkToCollectionResource(Catagory.class));
    }


    private static class CatagoryIdName {
        private final long id;
        private final String name;

        public CatagoryIdName(Catagory catagory) {
            id = catagory.getId();
            name = catagory.getName();
        }

        public long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }

}

