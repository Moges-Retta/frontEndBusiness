package com.investInEthio.ideas.domain;

import javax.persistence.*;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "catagories")
public class Catagory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;

    @OneToMany(mappedBy = "catagory")
    private Set<Product> products;

    public Catagory(String name) {
        this.name = name;
        this.products = new LinkedHashSet<>();
    }
    protected Catagory(){}

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Set<Product> getProducts() {
        return Collections.unmodifiableSet(products);
    }

    public boolean add(Product product) {
        var added = products.add(product);
        var oldCatagory = product.getCatagory();
        if (oldCatagory != null && oldCatagory != this) {
            oldCatagory.products.remove(product);
        }
        if (this != oldCatagory) {
            product.setCatagory(this);
        }
        return added;
    }
}
