package com.investInEthio.ideas.repositories;

import com.investInEthio.ideas.domain.Product;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product,Long> {
    Optional<Product> findById(long id);
    List<Product> findByTitleContaining(String name, Pageable pageable);
    List<Product> findByCatagoryName(String name);
}
