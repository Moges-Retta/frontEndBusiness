package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.NonUser;
import com.investInEthio.ideas.services.NonUserService;
import org.springframework.hateoas.server.EntityLinks;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/register")
@CrossOrigin(exposedHeaders = "Location")
@ExposesResourceFor(NonUser.class)
public class NonUserController {
    private final NonUserService service;
    private final EntityLinks entityLinks;

    public NonUserController(NonUserService service, EntityLinks entityLinks) {
        this.service = service;
        this.entityLinks = entityLinks;
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    HttpHeaders createNonUser(@RequestBody @Valid NonUser user){
        service.create(user);
        var link = entityLinks.linkToItemResource(NonUser.class, user.getId());
        var headers = new HttpHeaders();
        headers.setLocation(link.toUri());
        return headers;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Map<String, String> verkeerdeData(MethodArgumentNotValidException ex) {
        return ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));
    }
}
