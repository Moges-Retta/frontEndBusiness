package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.NonUser;
import com.investInEthio.ideas.domain.User;

public interface NonUserService {
    void create(NonUser user);
}
