package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.Catagory;

import java.util.List;
import java.util.Optional;

public interface CatagoryService {
    Optional<Catagory> findById(long id);
    List<Catagory> findALL();

}
