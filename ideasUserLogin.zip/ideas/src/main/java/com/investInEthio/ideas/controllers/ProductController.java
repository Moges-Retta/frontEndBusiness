package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.Catagory;
import com.investInEthio.ideas.domain.Product;
import com.investInEthio.ideas.services.CatagoryService;
import com.investInEthio.ideas.services.ProductService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.EntityLinks;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.stream.Collectors;

@RestController
@RequestMapping("/catagories")
@CrossOrigin(exposedHeaders = "Location")
@ExposesResourceFor(Product.class)
public class ProductController {

    private CatagoryService service;
    private final EntityLinks entityLinks;

    public ProductController(CatagoryService service, EntityLinks entityLinks) {
        this.service = service;
        this.entityLinks = entityLinks;
    }
    @GetMapping("{id}")
    CollectionModel<EntityModel<ProductIdName>> findAllProducts(@PathVariable long id) {
        return CollectionModel.of(service.findById(id).get().getProducts().stream()
                .map(product -> EntityModel.of(new ProductIdName(product),
                        entityLinks.linkToItemResource(Product.class, product.getId())))
                .collect(Collectors.toList()), entityLinks.linkToCollectionResource(Product.class));
    }
    private static class ProductIdName {
        private final long id;
        private final String name;
        private final String category;
        private final long categoryId;

        public ProductIdName(Product product) {
            id = product.getId();
            name = product.getTitle();
            category = product.getCatagory().getName();
            categoryId = product.getCatagory().getId();

        }

        public long getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getCategory() {
            return category;
        }

        public long getCategoryId() {
            return categoryId;
        }
    }

}
