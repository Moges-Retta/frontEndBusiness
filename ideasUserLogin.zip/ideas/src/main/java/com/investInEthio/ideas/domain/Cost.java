package com.investInEthio.ideas.domain;

import javax.persistence.*;
import java.util.Objects;

@Embeddable
@Access(AccessType.FIELD)
public class Cost {
    private int machinery;
    private int labor;

    public Cost(int machineryCost, int labor) {
        this.machinery = machinery;
        this.labor = labor;
    }
    protected Cost(){}

    public int getMachinery() {
        return machinery;
    }

    public void setMachinery(int machinery) {
        this.machinery = machinery;
    }

    public int getLabor() {
        return labor;
    }

    public void setLabor(int labor) {
        this.labor = labor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cost)) return false;
        Cost cost = (Cost) o;
        return machinery == cost.machinery &&
                labor == cost.labor;
    }

    @Override
    public int hashCode() {
        return Objects.hash(machinery, labor);
    }
}
