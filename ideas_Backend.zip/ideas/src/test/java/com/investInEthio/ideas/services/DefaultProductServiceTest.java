package com.investInEthio.ideas.services;

public class DefaultProductServiceTest {
}
