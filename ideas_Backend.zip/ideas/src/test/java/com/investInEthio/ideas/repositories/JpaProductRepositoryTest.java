package com.investInEthio.ideas.repositories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import javax.persistence.EntityManager;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
//@Import(JpaProductRepository.class)
@Sql({"/insertCatagory.sql", "/insertCity.sql", "/insertProduct.sql"})
public class JpaProductRepositoryTest extends AbstractTransactionalJUnit4SpringContextTests {
    private final ProductRepository repository;
    private static final String PRODUCTS = "products";

    public JpaProductRepositoryTest(ProductRepository repository) {
        this.repository = repository;
    }
    private int idVanTestProduct(){
        return super.jdbcTemplate.queryForObject(
                "select id from products where title='test'", Integer.class);
    }
    @Test
    void findById() {
        var product = repository.findById(idVanTestProduct()).get();
        assertThat(product.getTitle()).isEqualTo("test");
        assertThat(product.getCity().getName()).isEqualTo("test");
        assertThat(product.getCatagory().getName()).isEqualTo("test");
        assertThat(product.getCity().getCost()).isEqualTo(0);
    }
    @Test
    void findByOnbestaandeId() {
        assertThat(repository.findById(-1)).isNotPresent();
    }

    @Test
    void findByNameContains(){
        var products = repository.findByTitleContaining("test");
        assertThat(products).hasSize(
                super.countRowsInTableWhere(PRODUCTS, "title like '%test%'"))
                .allSatisfy(
                        product -> assertThat(product.getTitle()).isEqualTo("test"));
    }
    @Test
    void findProjectByCatagory(){
        var sql ="select name from catagories where name like '%test%'";
        var catagory = super.jdbcTemplate.queryForObject(sql,String.class);
        repository.findByCatagoryName(catagory).forEach(project->assertThat(project.getTitle()).isEqualTo("test"));
    }
}
