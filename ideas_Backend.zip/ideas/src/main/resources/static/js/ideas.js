document.getElementById("mySearch").size = "50";
