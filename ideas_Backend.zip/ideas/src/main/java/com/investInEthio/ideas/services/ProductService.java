package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.Product;

import java.util.List;
import java.util.Optional;

public interface ProductService {
    Optional<Product> findById(int id);
    List<Product> findByTitleContaining(String name);
    List<Product> findByCatagoryName(String name);
}
