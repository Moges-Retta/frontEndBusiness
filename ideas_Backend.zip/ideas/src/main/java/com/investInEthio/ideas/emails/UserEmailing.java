package com.investInEthio.ideas.emails;

import com.investInEthio.ideas.domain.User;

public interface UserEmailing {
    void sendEmail(User user, String usersURL);
}
