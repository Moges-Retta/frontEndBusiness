package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.Catagory;

import java.util.List;

public interface CatagoryService {
    List<Catagory> findByCatagoryName(String name);

}
