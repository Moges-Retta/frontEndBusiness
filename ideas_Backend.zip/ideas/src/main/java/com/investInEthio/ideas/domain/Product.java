package com.investInEthio.ideas.domain;

import javax.persistence.*;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private  String title;
    private  String description;
    private  String rationale;
    private  String marketPotential;
    private  String rawMaterial;
    private  String technology;
    private  String benefits;

    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "catagories_id")
    private Catagory catagory;

    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "cities_id")
    private City city;

    public Product(String title,String description, String rationale, String marketPotential, String rawMaterial, String technology,
                   String benefits,Catagory catagory,City city) {
        this.rationale = rationale;
        this.title=title;
        this.description=description;
        this.marketPotential = marketPotential;
        this.rawMaterial = rawMaterial;
        this.technology = technology;
        this.benefits = benefits;
        setCatagory(catagory);
        setCity(city);
    }
    protected Product(){}

    public int getId() {
        return id;
    }

    public String getRationale() {
        return rationale;
    }

    public String getMarketPotential() {
        return marketPotential;
    }

    public String getRawMaterials() {
        return rawMaterial;
    }

    public String getTechnology() {
        return technology;
    }

    public String getBenefits() {
        return benefits;
    }

    public String getTitle() {
        return title;
    }

    public void setCatagory(Catagory catagory) {
        if (!catagory.getProducts().contains(this)) {
            catagory.add(this);
        }
        this.catagory = catagory;
    }

    public Catagory getCatagory() {
        return catagory;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        if (!city.getProducts().contains(this)) {
            city.add(this);
        }
        this.city = city;
    }

    public String getDescription() {
        return description;
    }

    public String getRawMaterial() {
        return rawMaterial;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;
        Product product = (Product) o;
        return title.equals(product.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title);
    }
}
