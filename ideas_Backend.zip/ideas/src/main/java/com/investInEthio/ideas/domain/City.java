package com.investInEthio.ideas.domain;

import javax.persistence.*;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "cities")
public class City {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private int costPerAcer;

    @OneToMany(mappedBy = "city")
    private Set<Product> products;

    public City(String name, int cost) {
        this.name = name;
        this.costPerAcer = cost;
        this.products = new LinkedHashSet<>();
    }
    protected City(){}
    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public int getCostPerAcer() {
        return costPerAcer;
    }

    public int getCost() {
        return costPerAcer;
    }

    public Set<Product> getProducts() {
        return Collections.unmodifiableSet(products);
    }

    public boolean add(Product product) {
        var added = products.add(product);
        var oldCity = product.getCity();
        if (oldCity != null && oldCity != this) {
            oldCity.products.remove(product);
        }
        if (this != oldCity) {
            product.setCity(this);
        }
        return added;
    }
}
