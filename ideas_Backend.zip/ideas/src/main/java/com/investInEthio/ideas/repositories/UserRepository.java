package com.investInEthio.ideas.repositories;

import com.investInEthio.ideas.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping
public interface UserRepository extends JpaRepository<User,Long> {
}
