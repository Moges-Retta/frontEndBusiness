package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.User;
import com.investInEthio.ideas.emails.UserEmailing;
import com.investInEthio.ideas.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DefaultUserService implements UserService{
    private final UserRepository repository;
    private final UserEmailing userEmailing;
    public DefaultUserService(UserRepository repository, UserEmailing userEmailing) {
        this.repository = repository;
        this.userEmailing = userEmailing;
    }

    @Override
    public void register(User user, String usersURL) {
        repository.save(user);
        userEmailing.sendEmail(user, usersURL);
    }

    @Override
    public Optional<User> findById(long id) {
        return Optional.empty();
    }
}
