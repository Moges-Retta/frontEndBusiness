package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.User;

import java.util.Optional;

public interface UserService {
    void register(User user, String usersURL);
    Optional<User> findById(long id);
}
