package com.investInEthio.ideas.repositories;

import com.investInEthio.ideas.domain.Catagory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CatagoryRepository extends JpaRepository<Catagory,Integer> {
    List<Catagory> findByName(String name);
}
