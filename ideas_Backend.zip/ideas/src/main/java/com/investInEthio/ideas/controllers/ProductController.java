package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/product/{id}")
public class ProductController {
    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }
    @GetMapping
    public ModelAndView products(@PathVariable("id") int id) {
        var modelAndView = new ModelAndView("productDetail");
        var product = service.findById(id).get();
        var catagory = product.getCatagory().getName();
        modelAndView.addObject("productsDetail",product);
        return modelAndView;
    }
}
