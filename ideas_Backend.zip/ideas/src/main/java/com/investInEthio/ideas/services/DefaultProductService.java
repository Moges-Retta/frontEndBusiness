package com.investInEthio.ideas.services;

import com.investInEthio.ideas.domain.Product;
import com.investInEthio.ideas.repositories.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class DefaultProductService implements ProductService{
    private ProductRepository repository;

    public DefaultProductService(ProductRepository repository) {
        this.repository = repository;
    }

    @Override
    public Optional<Product> findById(int id) {
        return  Optional.of(repository.findById(id).get());
    }

    @Override
    public List<Product> findByTitleContaining(String name) {
        return repository.findByTitleContaining(name);
    }

    @Override
    public List<Product> findByCatagoryName(String name) {
        return repository.findByCatagoryName(name);
    }
}
