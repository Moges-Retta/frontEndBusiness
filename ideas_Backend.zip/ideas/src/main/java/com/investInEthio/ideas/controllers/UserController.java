package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.User;
import com.investInEthio.ideas.exceptions.CanNotsendEmail;
import com.investInEthio.ideas.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Controller
@RequestMapping("users")
public class UserController {
    private final UserService service;
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public UserController(UserService service) {
        this.service = service;
    }
    @GetMapping
    public ModelAndView registrationForm(){
        return new ModelAndView("registrationForm")
                .addObject( new User("","","",""));
    }
    @PostMapping
    public String regstreer(@Valid User user, Errors errors,
                            RedirectAttributes redirect, HttpServletRequest request) {
        if (errors.hasErrors()) {
            return "registrationForm";
        }
        try {
            service.register(user, request.getRequestURL().toString());
            redirect.addAttribute("id", user.getId());
            return "redirect:/users/registered/{id}";
        }
        catch (CanNotsendEmail ex) {
            logger.error("cannot send email", ex);
            return "redirect:/users/notregistered";
        }
    }
    @GetMapping("registered/{id}")
    public String geregistreerd(@PathVariable long id) {
        return "registered";
    }
    @GetMapping("notregistered")
    public String nietGeregistreerd() {
        return "notregistered";
    }

    @GetMapping("{id}")
    public ModelAndView info(@PathVariable long id) {
        var modelAndView = new ModelAndView("userInfo");
        service.findById(id).ifPresent(modelAndView::addObject);
        return modelAndView;
    }
}
