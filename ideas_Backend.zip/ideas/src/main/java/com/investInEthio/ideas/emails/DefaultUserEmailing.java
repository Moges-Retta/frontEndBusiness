package com.investInEthio.ideas.emails;

import com.investInEthio.ideas.domain.User;
import com.investInEthio.ideas.exceptions.CanNotsendEmail;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;

@Component
public class DefaultUserEmailing implements UserEmailing{
    private final JavaMailSender sender;

    public DefaultUserEmailing(JavaMailSender sender) {
        this.sender = sender;
    }

    @Override
    public void sendEmail(User user, String usersURL) {
        try {
            var message = sender.createMimeMessage();
            var helper = new MimeMessageHelper(message);
            helper.setTo(user.getEmailAdres());
            helper.setSubject("Registered");
            var urlOfUserInfo = usersURL + "/" + user.getId();
            var tekst = "<h1>You are now a member.</h1>Your number is:" +
                    user.getId() + "." + "Registration information: <a href='"
                    + urlOfUserInfo + "'>here</a>.";
            helper.setText(tekst, true);
            sender.send(message);
        }
        catch (MailException | MessagingException ex) {
            throw new CanNotsendEmail(ex);
        }
    }
}
