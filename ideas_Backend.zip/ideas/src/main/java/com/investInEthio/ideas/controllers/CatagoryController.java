package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.domain.Product;
import com.investInEthio.ideas.services.CatagoryService;
import com.investInEthio.ideas.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.LinkedList;

@Controller
@RequestMapping(value="/{catagory}",method = RequestMethod.GET)
public class CatagoryController {
    private CatagoryService service;

    public CatagoryController(CatagoryService service) {
        this.service = service;
    }

    @GetMapping
    public ModelAndView products(@PathVariable("catagory") String catagory) {
        var products = new LinkedList<Product>();
        service.findByCatagoryName(catagory).forEach(catagory1 ->
                products.addAll(catagory1.getProducts()));
        return new ModelAndView("product","products",products);
    }
}
