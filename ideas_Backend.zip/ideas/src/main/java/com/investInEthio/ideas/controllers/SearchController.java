package com.investInEthio.ideas.controllers;

import com.investInEthio.ideas.services.ProductService;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/search",method = RequestMethod.GET)
public class SearchController {
    private final ProductService service;

    public SearchController(ProductService service) {
        this.service = service;
    }
    @GetMapping
    public ModelAndView search(@RequestParam String keyword) {
        return new ModelAndView("product","products",
                service.findByTitleContaining(keyword));
    }
}
